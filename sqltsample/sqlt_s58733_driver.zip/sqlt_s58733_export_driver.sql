REM $Header: 215187.1 sqlt_s58733_export_driver.sql 12.1.160429 2017/05/26 abel.macias $
SPO sqltxtract.log APPEND;
EXEC ^^tool_administer_schema..sqlt$a.write_log('-> Export Driver','L',' drivers');
SPO OFF;
SET TERM ON
PRO
PRO *******************************************************************
PRO * Enter SQLTXPLAIN valid password to export SQLT repository       *
PRO * Notes:                                                          *
PRO * 1. If you entered an incorrect password you will have to enter  *
PRO *    now both USER and PASSWORD. The latter is case sensitive     *
PRO * 2. User is SQLTXPLAIN and not your application user.            *
PRO *******************************************************************
HOS exp sqltxplain/^^enter_tool_password. parfile=sqlt_s58733_export_parfile2.txt
HOS exp sqltxplain/^^enter_tool_password. parfile=sqlt_s58733_export_parfile.txt
SET TERM OFF;
HOS chmod 777 sqlt_s58733_import.sh
HOS zip -m sqlt_s58733_tc sqlt_s58733_exp.dmp
HOS zip -m sqlt_s58733_tc sqlt_s58733_import.sh
HOS zip -m sqlt_s58733_tcx sqlt_s58733_exp2.dmp
HOS zip -m sqlt_s58733_log sqlt_s58733_exp.log
HOS zip -m sqlt_s58733_log sqlt_s58733_exp2.log
HOS zip -m sqlt_s58733_driver sqlt_s58733_export_driver.sql
HOS zip -m sqlt_s58733_driver sqlt_s58733_export_parfile.txt
HOS zip -m sqlt_s58733_driver sqlt_s58733_export_parfile2.txt
SPO sqltxtract.log APPEND;
EXEC ^^tool_administer_schema..sqlt$a.write_log('<- Export Driver','L',' drivers');
SPO OFF;

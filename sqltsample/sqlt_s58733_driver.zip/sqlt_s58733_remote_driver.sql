REM $Header: 215187.1 sqlt_s58733_remote_driver.sql 12.1.160429 2017/05/26 abel.macias $
SPO sqltxtract.log APPEND;
EXEC ^^tool_administer_schema..sqlt$a.write_log('-> Remote Driver','L',' drivers');
SPO OFF;
--
HOS zip -m sqlt_s58733_driver sqlt_s58733_remote_driver.sql
SPO sqltxtract.log APPEND;
EXEC ^^tool_administer_schema..sqlt$a.write_log('<- Remote Driver','L',' drivers');
SPO OFF;

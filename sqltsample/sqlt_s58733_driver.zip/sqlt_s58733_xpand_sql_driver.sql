REM $Header: 215187.1 sqlt_s58733_xpand_sql_driver.sql 12.1.160429 2017/05/26 abel.macias $

SPO sqltxtract.log APPEND;
EXEC ^^tool_administer_schema..sqlt$a.write_log('-> XPAND SQL Driver','L',' drivers');
SPO OFF
VAR c1 CLOB
VAR c2 CLOB
BEGIN
 SELECT SQL_TEXT_CLOB INTO :c1 FROM sqltxadmin.sqlt$_sql_statement WHERE statement_id = 58733;
END;
/
EXEC DBMS_UTILITY.EXPAND_SQL_TEXT(:c1,:c2);
SET LINE 220 PAGESIZE 0 LONG 1000000 LONGCHUNKSIZE 1000000
SPOO sqlt_s58733_xpand.sql
SELECT :c2 FROM DUAL;
SPOO OFF
SPO sqltxtract.log APPEND;
EXEC ^^tool_administer_schema..sqlt$a.write_log('<- XPAND SQL Driver','L',' drivers');
SPO OFF;

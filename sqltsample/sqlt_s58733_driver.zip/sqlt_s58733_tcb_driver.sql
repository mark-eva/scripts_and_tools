REM $Header: 215187.1 sqlt_s58733_tcb_driver.sql 12.1.160429 2017/05/26 abel.macias $
SPO sqltxtract.log APPEND;
EXEC ^^tool_administer_schema..sqlt$a.write_log('-> TCB Driver','L',' drivers');
SPO OFF
HOS zip -j sqlt_s58733_tcb /oracle/diag/rdbms/test/test/trace/sqlt_s58733_tcb_* /oracle/diag/rdbms/test/test/trace/README.txt
HOS zip -m sqlt_s58733_driver sqlt_s58733_tcb_driver.sql
SPO sqltxtract.log APPEND;
EXEC ^^tool_administer_schema..sqlt$a.write_log('<- TCB Driver','L',' drivers');
SPO OFF

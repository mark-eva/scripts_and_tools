SET ECHO OFF
REM
PAU 1/3 Press ENTER to create setup.sql script.
REM create setup.sql script
SPO setup.sql
PRO REM Implements Test Case TC58733.
PRO REM Just execute "sqlplus / as sysdba @setup.sql" from OS.
PRO REM
PRO SPO setup.log
PRO SET ECHO ON SERVEROUT OFF
PRO REM
PRO REM create tc user.
PRO GRANT DBA TO TC58733 IDENTIFIED BY TC58733;;
PRO REM
PRO REM create cbo stats staging table.
PRO ALTER SESSION SET NLS_LENGTH_SEMANTICS = BYTE;
PRO EXEC SYS.DBMS_STATS.CREATE_STAT_TABLE(ownname => 'TC58733', stattab => 'SQLT$_STATTAB');;
PRO DROP INDEX TC58733.SQLT$_STATTAB;;
PRO REM
PRO REM delete in case we execute this script more than once.
PRO DELETE TC58733.sqlt$_stattab;;
PRO REM
PRO REM import schema objects including cbo stats.
PRO HOS imp TC58733/TC58733 FILE=TC58733_expdat.dmp LOG=TC58733_import.log FULL=Y IGNORE=Y
PRO REM
PRO REM upgrade cbo stats table in case source is prior release.
PRO EXEC SYS.DBMS_STATS.UPGRADE_STAT_TABLE(ownname => 'TC58733', stattab => 'SQLT$_STATTAB');
PRO REM
PRO REM restore schema object stats.
PRO EXEC SYS.DBMS_STATS.IMPORT_SCHEMA_STATS(ownname => 'TC58733', stattab => 'SQLT$_STATTAB');;
PRO REM
PRO REM display table level cbo stats.
PRO SELECT table_name, num_rows FROM sys.dba_tables WHERE owner = 'TC58733' AND table_name <> 'SQLT$_STATTAB' ORDER BY table_name;;
PRO SPO OFF
PRO REM
PRO REM create metadata for views and packages.
PRO @@sqlt_s58733_metadata2.sql
PRO REM
PRO REM restore system statistics.
PRO @@sqlt_s58733_system_stats.sql
PRO REM
PRO REM connect as the tc user.
PRO CONN TC58733/TC58733
PRO REM
PRO REM setup cbo environment.
PRO @@sqlt_s58733_set_cbo_env.sql
PRO REM
PRO REM execute SQL.
PRO @@q.sql
PRO REM
PRO REM display execution plan.
PRO @@plan.sql
PRO REM
PRO SET ECHO OFF
SPO OFF
REM
PAU 2/3 Press ENTER to create readme.txt file.
REM create readme.txt file
SPO readme.txt
PRO REM connect as sys and execute setup.sql
PRO sqlplus / as sysdba @setup.sql
SPO OFF
HOS chmod 777 readme.txt
REM
PAU 3/3 Press ENTER to package test case into tcx.zip.
SPO pack_tcx.log
REM export schema stats in case we changed them during tc.
DELETE TC58733.sqlt$_stattab;
EXEC SYS.DBMS_STATS.EXPORT_SCHEMA_STATS(ownname => 'TC58733', stattab => 'SQLT$_STATTAB');
REM
REM export schema objects for tcx.
HOS exp TC58733/TC58733 FILE=TC58733_expdat.dmp LOG=TC58733_export.log TABLES=TC58733.% STATISTICS=NONE
REM
REM creates zip with tcx files.
HOS zip tcx TC58733_expdat.dmp
HOS zip tcx sqlt_s58733_metadata2.sql
HOS zip tcx sqlt_s58733_system_stats.sql
HOS zip tcx sqlt_s58733_set_cbo_env.sql
HOS zip tcx q.sql
HOS zip tcx plan.sql
HOS zip tcx 10053.sql
HOS zip tcx flush.sql
HOS zip -m tcx setup.sql
HOS zip -m tcx readme.txt
REM
REM creates tcx directory (for your review).
HOS unzip tcx.zip -d tcx
REM
PRO tcx directory and zip have been created.
PRO review, adjust and test them on another system.
SPO OFF

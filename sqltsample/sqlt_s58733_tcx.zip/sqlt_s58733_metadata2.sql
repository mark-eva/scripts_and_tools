SPO sqlt_s58733_metadata2.log;
SET DEF ^ ECHO ON TERM ON LIN 2000 TRIMS ON APPI OFF SERVEROUT ON SIZE 1000000;
REM
REM $Header: 215187.1 sqlt_s58733_metadata2.sql 12.1.160429 2017/05/26 abel.macias $
REM
REM Copyright (c) 2000-2015, Oracle Corporation. All rights reserved.
REM
REM AUTHOR
REM   abel.macias@oracle.com
REM
REM SCRIPT
REM   sqlt_s58733_metadata2.sql
REM
REM SOURCE
REM   Host    : fiv-dev-db9.fivium.local
REM   DB Name : TEST
REM   Platform: Linux
REM   Product : Oracle Database 12c Standard Edition (64bit Production)
REM   Version : 12.1.0.2.0
REM   Language: GB:ENGLISH_UNITED KINGDOM.WE8MSWIN1252
REM   EBS     : NO
REM   Siebel  : NO
REM   PSFT    : NO
REM
REM DESCRIPTION
REM   This script is generated automatically by the SQLT tool.
REM   It contains the SQL*Plus commands to create a test case user
REM   and its set of schema objects referenced by the SQL statement
REM   analyzed by SQLT.
REM
REM PARAMETERS
REM   TC_USER_SUFFIX: (optional)
REM   Hit "Enter" key if you dont want a test case user suffix, or
REM   type in a suffix for the TC user.
REM
REM EXAMPLE
REM   SQL> START sqlt_s58733_metadata2.sql;
REM
REM NOTES
REM   1. Review and edit "CUSTOMIZATION" section below.
REM   2. Should be run as SYSDBA.
REM

/**********************************************************************/
/* CUSTOMIZATION - BEGIN
/**********************************************************************/

-- Create test case user.
DEF TC_USER = TC58733;
GRANT DBA TO ^^TC_USER. IDENTIFIED BY ^^TC_USER.;

-- Consolidate objects into one test case user.

/**********************************************************************/
/* CUSTOMIZATION - END
/**********************************************************************/



/**********************************************************************/

REM TYPE, TYPE BODY and INDEXTYPE


/**********************************************************************/

REM TABLE and MATERIALIZED VIEW

/**********************************************************************/

REM INDEX


/**********************************************************************/

REM STATISTICS EXTENSIONS


/**********************************************************************/

REM CONSTRAINT


/**********************************************************************/

REM PACKAGE


/**********************************************************************/

REM VIEW


/**********************************************************************/

REM FUNCTION, PROCEDURE, LIBRARY and PACKAGE BODY


/**********************************************************************/

REM OTHERS



/**********************************************************************/

SET ECHO OFF VER OFF PAGES 1000 LIN 80 LONG 8000000 LONGC 800000;

VAR valid_objects CLOB;
VAR invalid_objects CLOB;
DECLARE
  l_status VARCHAR2(7);
  PROCEDURE x (p_type IN VARCHAR2, p_owner IN VARCHAR2, p_name IN VARCHAR2) IS
  BEGIN
    BEGIN
      SELECT status
        INTO l_status
        FROM sys.dba_objects
       WHERE object_type = p_type
         AND owner = p_owner
         AND object_name = p_name;
    EXCEPTION
      WHEN OTHERS THEN
        l_status := 'INVALID';
    END;
    IF l_status = 'VALID' THEN
      :valid_objects := :valid_objects||CHR(10)||l_status||' '||p_type||' '||p_owner||' '||p_name;
    ELSE
      :invalid_objects := :invalid_objects||CHR(10)||l_status||' '||p_type||' '||p_owner||' '||p_name;
    END IF;
  END;
BEGIN
:valid_objects := NULL;
:invalid_objects := NULL;
:valid_objects := TRIM(CHR(10) FROM :valid_objects);
:invalid_objects := TRIM(CHR(10) FROM :invalid_objects);
END;
/

SET TERM ON;
SELECT :valid_objects FROM DUAL;
SELECT :invalid_objects FROM DUAL;


/**********************************************************************/

SET DEF ON ECHO ON APPI OFF SERVEROUT OFF PAGES 24 LIN 80 LONG 80 LONGC 80;
REM In case of INVALID OBJECTS: review log, fix errors and execute again.
SPO OFF;

SPO sqlt_s58733_schema_stats.log;
SET ECHO ON TERM ON;
REM
REM $Header: 215187.1 sqlt_s58733_schema_stats.sql 12.1.160429 2017/05/26 abel.macias $
REM
REM Copyright (c) 2000-2015, Oracle Corporation. All rights reserved.
REM
REM AUTHOR
REM   abel.macias@oracle.com
REM
REM SCRIPT
REM   sqlt_s58733_schema_stats.sql
REM
REM SOURCE
REM   Host    : fiv-dev-db9.fivium.local
REM   DB Name : TEST
REM   Platform: Linux
REM   Product : Oracle Database 12c Standard Edition (64bit Production)
REM   Version : 12.1.0.2.0
REM   Language: GB:ENGLISH_UNITED KINGDOM.WE8MSWIN1252
REM   EBS     : NO
REM   Siebel  : NO
REM   PSFT    : NO
REM
REM DESCRIPTION
REM   This script is generated automatically by the SQLT tool.
REM   It contains the SQL*Plus commands to set the CBO Schema
REM   Statistics as found on fiv-dev-db9.fivium.local
REM   at the time SQL g4pkmrqrgxg3b was analyzed by SQLT.
REM
REM PARAMETERS
REM   None.
REM
REM EXAMPLE
REM   SQL> START sqlt_s58733_schema_stats.sql;
REM
REM NOTES
REM   1. Should be run as SYSTEM or SYSDBA.
REM

-- create staging table for cbo schema stats
ALTER SESSION SET NLS_LENGTH_SEMANTICS = BYTE;
EXEC SYS.DBMS_STATS.CREATE_STAT_TABLE(ownname => '&&tc_user.', stattab => 'SQLT$_STATTAB');
DROP INDEX &&tc_user..sqlt$_stattab;

-- delete in case we execute this script more than once
DELETE &&tc_user..sqlt$_stattab;

-- import schema object statistics into staging table
HOS imp &&tc_user./&&tc_user. FILE=sqlt_s58733_exp2.dmp LOG=sqlt_s58733_imp2.log FULL=Y IGNORE=Y

-- upgrade cbo stats table in case source is prior release
EXEC SYS.DBMS_STATS.UPGRADE_STAT_TABLE(ownname => '&&tc_user.', stattab => 'SQLT$_STATTAB');

-- reset statid and owner on staging table
UPDATE &&tc_user..sqlt$_stattab SET statid = NULL;
UPDATE &&tc_user..sqlt$_stattab SET c5 = '&&tc_user.' WHERE c5 IS NOT NULL;
COMMIT;

-- imports into data dictionary schema stats for TC user out of staging table
EXEC SYS.DBMS_STATS.IMPORT_SCHEMA_STATS(ownname => '&&tc_user.', stattab => 'SQLT$_STATTAB');

-- displays stats that were just imported
SELECT table_name, num_rows FROM sys.dba_tables WHERE owner = '&&tc_user.' AND table_name <> 'SQLT$_STATTAB' ORDER BY table_name;

SPO OFF;

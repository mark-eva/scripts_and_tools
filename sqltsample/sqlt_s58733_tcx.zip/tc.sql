REM Executes SQL on TC then produces execution plan. Just execute "@tc.sql" from sqlplus.
SET APPI OFF SERVEROUT OFF;
@@q.sql
@@plan.sql

REM Implements SQLT TCX (Test Case eXpress).
REM Just execute "./install.sh" or "sqlplus / as sysdba @install.sql" from OS.
SET ECHO OFF;
CL SCR
PRO Metadata1: types, tables, indexes, contraints.
PAU 1/6 Press ENTER to create TC user and base schema objects.
SET ECHO ON;
@@sqlt_s58733_metadata1.sql
SET ECHO OFF;
PRO
PRO Metadata2: types, packages, views, others.
PAU 2/6 Press ENTER to create additional schema objects.
SET ECHO ON;
@@sqlt_s58733_metadata2.sql
SET ECHO OFF;
PRO
PAU 3/6 Press ENTER to import schema object statistics.
SET ECHO ON;
@@sqlt_s58733_schema_stats.sql
SET ECHO OFF;
PRO
PAU 4/6 Press ENTER to restore system statistics.
SET ECHO ON;
@@sqlt_s58733_system_stats.sql
SET ECHO OFF;
PRO
PAU 5/6 Press ENTER to connect as &&tc_user. and set CBO env.
SET ECHO ON;
CONN &&tc_user./&&tc_user.
@@sqlt_s58733_set_cbo_env.sql
SET ECHO OFF;
PRO
PAU 6/6 Press ENTER to execute test case.
SET ECHO ON;
@@tc.sql

# Implements SQLT TCX (Test Case eXpress).
# Just execute ". install.sh" from OS.
sqlplus / as sysdba @install.sql

select count(*) from dba_objects;

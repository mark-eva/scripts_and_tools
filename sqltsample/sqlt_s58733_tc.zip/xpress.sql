REM Implements SQLT Test Case (Express Mode).
REM Just execute "./xpress.sh" or "sqlplus / as sysdba @xpress.sql" from OS.
SET ECHO OFF;
CL SCR
PAU 1/7 Press ENTER to create TC user and schema objects for statement_id 58733.
SET ECHO ON;
@@sqlt_s58733_metadata.sql
SET ECHO OFF;
PRO
PAU 2/7 Press ENTER to purge statement_id 58733 from SQLT repository.
SET ECHO ON;
@@sqlt_s58733_purge.sql
SET ECHO OFF;
PRO
PAU 3/7 Press ENTER to import SQLT repository for statement_id 58733.
SET ECHO ON;
HOS imp SQLTXPLAIN FILE=sqlt_s58733_exp.dmp LOG=sqlt_s58733_imp.log TABLES=sqlt% IGNORE=Y
SET ECHO OFF;
PRO
PAU 4/7 Press ENTER to restore schema object stats for &&tc_user..
SET ECHO ON;
@@sqlt_s58733_restore.sql
SET ECHO OFF;
PRO
PAU 5/7 Press ENTER to restore system statistics.
SET ECHO ON;
@@sqlt_s58733_system_stats.sql
SET ECHO OFF;
PRO
PAU 6/7 Press ENTER to connect as &&tc_user. and set CBO env.
SET ECHO ON;
CONN &&tc_user./&&tc_user.
@@sqlt_s58733_set_cbo_env.sql
SET ECHO OFF;
PRO
PAU 7/7 Press ENTER to execute test case.
SET ECHO ON;
@@tc.sql

# Implements SQLT Test Case (Express Mode).
# Just execute ". xpress.sh" from OS.
sqlplus / as sysdba @xpress.sql

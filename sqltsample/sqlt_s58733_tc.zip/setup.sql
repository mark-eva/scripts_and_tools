@@sqlt_s58733_system_stats.sql
DEF TC_USER_SUFFIX = "";
@@sqlt_s58733_metadata.sql
HOS imp TC58733/TC58733 FILE=cbo_stat_tab_4tc.dmp LOG=cbo_stat_tab_4tc.log TABLES=cbo_stat_tab_4tc IGNORE=Y
CONN TC58733/TC58733
REM Ignore errors by UPGRADE_STAT_TABLE api call below:
EXEC SYS.DBMS_STATS.UPGRADE_STAT_TABLE(USER,'CBO_STAT_TAB_4TC');
EXEC SYS.DBMS_STATS.IMPORT_SCHEMA_STATS(USER,'CBO_STAT_TAB_4TC');
@@sqlt_s58733_set_cbo_env.sql
@@tc.sql

SPO sqlt_s58733_system_stats.log;
SET ECHO ON TERM ON;
REM
REM $Header: 215187.1 sqlt_s58733_system_stats.sql 12.1.160429 2017/05/26 abel.macias $
REM
REM Copyright (c) 2000-2015, Oracle Corporation. All rights reserved.
REM
REM AUTHOR
REM   abel.macias@oracle.com
REM
REM SCRIPT
REM   sqlt_s58733_system_stats.sql
REM
REM SOURCE
REM   Host    : fiv-dev-db9.fivium.local
REM   DB Name : TEST
REM   Platform: Linux
REM   Product : Oracle Database 12c Standard Edition (64bit Production)
REM   Version : 12.1.0.2.0
REM   Language: GB:ENGLISH_UNITED KINGDOM.WE8MSWIN1252
REM   EBS     : NO
REM   Siebel  : NO
REM   PSFT    : NO
REM
REM DESCRIPTION
REM   This script is generated automatically by the SQLT tool.
REM   It contains the SQL*Plus commands to set the CBO System
REM   Statistics as found on fiv-dev-db9.fivium.local
REM   at the time SQL g4pkmrqrgxg3b was analyzed by SQLT.
REM
REM PARAMETERS
REM   None.
REM
REM EXAMPLE
REM   SQL> START sqlt_s58733_system_stats.sql;
REM
REM NOTES
REM   1. Should be run as SYSTEM or SYSDBA.
REM

EXEC SYS.DBMS_STATS.DELETE_SYSTEM_STATS;
EXEC SYS.DBMS_STATS.SET_SYSTEM_STATS('CPUSPEEDNW', 3007.76531492666);
EXEC SYS.DBMS_STATS.SET_SYSTEM_STATS('IOSEEKTIM', 10);
EXEC SYS.DBMS_STATS.SET_SYSTEM_STATS('IOTFRSPEED', 4096);

SPO OFF;

SPO tc_pkg.log
SET ECHO OFF
REM
REM export schema stats in case we changed them during tc.
DELETE TC58733.CBO_STAT_TAB_4TC;
EXEC SYS.DBMS_STATS.EXPORT_SCHEMA_STATS(ownname => 'TC58733', stattab => 'CBO_STAT_TAB_4TC', statown => 'TC58733');
REM
REM export schema objects for tc.
HOS exp TC58733/TC58733 FILE=cbo_stat_tab_4tc.dmp LOG=cbo_stat_tab_4tc.log TABLES=cbo_stat_tab_4tc STATISTICS=NONE
REM
REM creates zip with tc files.
HOS zip tc cbo_stat_tab_4tc.dmp
HOS zip tc sqlt_s58733_metadata.sql
HOS zip tc sqlt_s58733_opatch.zip
HOS zip tc sqlt_s58733_system_stats.sql tc.sql
HOS zip tc sqlt_s58733_set_cbo_env.sql
HOS zip tc q.sql
HOS zip tc plan.sql
HOS zip tc tc.sql
HOS zip tc 10053.sql
HOS zip tc flush.sql
HOS zip tc setup.sql
HOS zip tc readme.txt
REM
REM creates tc directory (for your review).
HOS unzip tc.zip -d tc
REM
PRO tc directory and zip have been created.
PRO review, adjust and test them on another system.
SPO OFF

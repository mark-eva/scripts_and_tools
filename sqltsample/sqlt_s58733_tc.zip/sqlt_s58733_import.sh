# $Header: 215187.1 sqlt_s58733_import.sh 12.1.160429 2017/05/26 abel.macias $
#
# Host    : fiv-dev-db9.fivium.local
# DB Name : TEST
# Platform: Linux
# Product : Oracle Database 12c Standard Edition (64bit Production)
# Version : 12.1.0.2.0
# Language: GB:ENGLISH_UNITED KINGDOM.WE8MSWIN1252
# EBS     : NO
# Siebel  : NO
# PSFT    : NO
#
# If you need to import all reports and scripts produced by SQLT
# dmp file must contain them first. Then use sql% instead of sqlt%.
#
imp sqltxplain FILE=sqlt_s58733_exp.dmp TABLES=sqlt% IGNORE=Y
#
# Notes:
# (1) To execute enter: ./sqlt_s58733_import.sh
# (2) File sqlt_s58733_exp.dmp should be placed in same directory than this script.

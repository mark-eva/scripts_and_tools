connect as sys and execute setup.sql

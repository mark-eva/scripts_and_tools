REM $Header: 215187.1 sqlt_s58733_tc_script.sql 12.1.160429 2017/05/26 abel.macias $


select /* ^^unique_id */ count(*) from dba_objects;
